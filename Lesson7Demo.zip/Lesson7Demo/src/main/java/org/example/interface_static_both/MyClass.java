package org.example.interface_static_both;


public class MyClass implements Intface1, Intface2 {

}
