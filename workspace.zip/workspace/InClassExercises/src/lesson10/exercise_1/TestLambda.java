package lesson10.exercise_1;

import org.junit.Test;

import junit.framework.TestCase;

public class TestLambda extends TestCase {
	@Test
	public void testLambda() {
		//your test 
	}
}
