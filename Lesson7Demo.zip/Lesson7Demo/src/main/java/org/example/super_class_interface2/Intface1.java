package org.example.super_class_interface2;

public interface Intface1 {
    void aMethod(int x);
}
