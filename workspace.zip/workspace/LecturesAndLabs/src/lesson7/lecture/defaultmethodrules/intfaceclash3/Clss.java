package lesson7.lecture.defaultmethodrules.intfaceclash3;

public class Clss implements Sup1, Sup2{
	//must implement
	public void myMethod() {
		int x = 1;
	}
}
