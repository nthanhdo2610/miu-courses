package lesson5.exercise_2;

//public class MyClass implements Iface1, Iface2 {
//	public int myMethod(int x) {
//		return x + 1;
//	}
//}
