package org.example.interface_one_static_interface2;


public class MyClass implements Intface1, Intface2 {

}
