package org.example.super_class_interface;

public class SuperClass {
    public void aMethod(int x)  {
        System.out.println("super class - aMethod");
    }
}
