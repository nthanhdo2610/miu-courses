package lesson10.labsolns.prob5;

public class SingleThreadedTest {	
	public static void main(String[] args) {
		SingleThreadedTest stt = new SingleThreadedTest();
		for(int i = 0; i < 10; ++i) {
			stt.createAndStartThread();
		}
		System.out.println("Number of elements in the queue: " + stt.q.countElements());
	}
	final Queue q = new Queue();
	
	
	public void createAndStartThread() {
		Runnable r = () -> {
			for(int i = 0; i < 1000; ++i) {
				q.add(0);q.add(0);q.remove();
			}		
		};
		new Thread(r).start();
		try {
			Thread.sleep(10);
		} catch(InterruptedException e) {}
	}

}
