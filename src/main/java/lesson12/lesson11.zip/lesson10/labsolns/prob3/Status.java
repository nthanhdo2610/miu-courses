package lesson10.labsolns.prob3;

public enum Status {
	GOLD, SILVER, COMMON, ILLEGAL
}
