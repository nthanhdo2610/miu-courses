package lesson8.exercise_2;

public interface MyIface {

}
