package lesson6.lab6.model;

import java.io.Serializable;

public enum Auth implements Serializable {
	MEMBER, SELLER, BOTH, ANONYMOUS;
}
