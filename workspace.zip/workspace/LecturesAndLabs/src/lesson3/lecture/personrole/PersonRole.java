package lesson3.lecture.personrole;

public class PersonRole {
    //package level
	PersonRole() {}
}
