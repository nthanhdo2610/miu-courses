package lesson10.labsolns.prob3;

public enum Gender {
	M, F
}
