package org.example.interface_interface;

public interface Intface2 {
    void aMethod(int x);
}
