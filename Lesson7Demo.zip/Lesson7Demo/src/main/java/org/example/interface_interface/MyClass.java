package org.example.interface_interface;

public class MyClass implements Intface1, Intface2{

    @Override
    public void aMethod(int x) {
        System.out.println(x);
    }
}
