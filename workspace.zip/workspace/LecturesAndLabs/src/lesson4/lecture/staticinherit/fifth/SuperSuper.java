package lesson4.lecture.staticinherit.fifth;

public class SuperSuper {
	static void tryit() {
		System.out.println("super super");
	}
}
