package lesson4.lecture.staticinherit.third;

//Shows an instance method cannot override a static method
public class Sub extends Super {
	public static void main(String[] args) {
		
	}
//	public void tryit() {
//		System.out.println("trying it too");
//	}
}
