package org.example.interface_one_static_interface;

public interface Intface2 {
    void aMethod(int x);
}
