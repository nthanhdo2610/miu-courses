package org.example.sub_interface2;

public class MyClass implements Intface3 {
//    @Override
//    public void aMethod(int x) {
//
//    }

    //a
//    public static void main(String[] args) {
//        new MyClass().aMethod(10);
//    }
    //b

}
