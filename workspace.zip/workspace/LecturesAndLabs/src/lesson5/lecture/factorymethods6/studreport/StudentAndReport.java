package lesson5.lecture.factorymethods6.studreport;

public interface StudentAndReport {
	public Student getStudent();
	public GradeReport getReport();
}
