package org.example.ex_7_3;

public class Impl implements Iface1, Iface2 {
	
}
