package lesson10.labs.prob3;

public enum Gender {
	M, F
}
