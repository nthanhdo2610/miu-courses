package lesson4.labs.prob4E;

public class Employee {
	public double computeUpdatedBalanceSum() {
		//implement
		return 0.0;
	}
}
