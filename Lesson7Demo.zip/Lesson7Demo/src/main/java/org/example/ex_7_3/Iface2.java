package org.example.ex_7_3;

public interface Iface2 {
	static int myMethod(int x) {
		return x + 1;
	}
}


