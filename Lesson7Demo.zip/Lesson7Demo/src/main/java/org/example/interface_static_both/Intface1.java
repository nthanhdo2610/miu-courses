package org.example.interface_static_both;

public interface Intface1 {
    static void aMethod(int x) {
        System.out.println("static in Intface1");
    }
}
