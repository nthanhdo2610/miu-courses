package org.example.sub_interface1;

public interface Intface2 {
    void aMethod(int x);
}
