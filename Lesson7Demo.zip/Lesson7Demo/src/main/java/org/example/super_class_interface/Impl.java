package org.example.super_class_interface;

public class Impl extends SuperClass implements Intface1{
    public static void main(String[] args) {
        new Impl().aMethod(10);
    }
}
