package org.example.interface_interface;

public interface Intface1 {
    void aMethod(int x);
}
