package lesson10.lecture.annotation;

@BugReport
public class MoreBadCode {
	public int subtract(int a, int b) {
		return a + b;
	}
}
