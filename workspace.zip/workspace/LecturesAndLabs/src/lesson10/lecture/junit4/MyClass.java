package lesson10.lecture.junit4;

public class MyClass {
	public int myMethod(String s) {
		return s.length();
	}
}
