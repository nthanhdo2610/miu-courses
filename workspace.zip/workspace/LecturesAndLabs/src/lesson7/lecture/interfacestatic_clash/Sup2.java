package lesson7.lecture.interfacestatic_clash;

public interface Sup2 {
	public static int myMethod() {
		return 2;
	}
}
