package lesson5.exercise_2;

public interface Iface1 {
	int myMethod(int x);
}
